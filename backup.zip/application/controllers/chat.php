<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat extends CI_Controller {

	public function index()
	{
		
	}

}

/* End of file chat.php */
/* Location: ./application/controllers/chat.php */