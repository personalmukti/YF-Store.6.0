<div class="list-group">
    <a href="<?= base_url(); ?>administrator/setting/general" class="list-group-item list-group-item-action"> Umum</a>
    <a href="<?= base_url(); ?>administrator/setting/navmenu" class="list-group-item list-group-item-action"> Navigasi Menu</a>
    <a href="<?= base_url(); ?>administrator/setting/banner" class="list-group-item list-group-item-action">Banner Slider</a>
    <a href="<?= base_url(); ?>administrator/setting/description" class="list-group-item list-group-item-action">Deskripsi Singkat</a>
    <a href="<?= base_url(); ?>administrator/setting/sosmed" class="list-group-item list-group-item-action">Sosial Media</a>
    <a href="<?= base_url(); ?>administrator/setting/address" class="list-group-item list-group-item-action">Alamat</a>
    <a href="<?= base_url(); ?>administrator/setting/delivery" class="list-group-item list-group-item-action">Biaya Antar</a>
    <a href="<?= base_url(); ?>administrator/setting/cod" class="list-group-item list-group-item-action">Cash On Delivery</a>
    <a href="<?= base_url(); ?>administrator/setting/footer" class="list-group-item list-group-item-action">Footer</a>
</div>